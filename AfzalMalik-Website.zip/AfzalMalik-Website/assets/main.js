/* ═══════════════════════════════════════════════════
   AFZAL MALIK — SHARED JS
   iafzalmalik.me
═══════════════════════════════════════════════════ */

// ─── NAV SCROLL ───────────────────────────────────
const nav = document.querySelector('.nav');
if (nav) {
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  });
}

// ─── MOBILE NAV ───────────────────────────────────
function toggleMobileNav() {
  document.getElementById('mobileNav').classList.toggle('open');
}

// ─── ACTIVE NAV LINK ──────────────────────────────
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-links a, .mobile-nav a').forEach(a => {
  if (a.getAttribute('href') === currentPage) a.classList.add('active');
});

// ─── SCROLL REVEAL ────────────────────────────────
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      revealObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

// ─── STAGGER CHILDREN ─────────────────────────────
document.querySelectorAll('.grid-3, .grid-2, .grid-4').forEach(grid => {
  [...grid.children].forEach((child, i) => {
    child.style.transitionDelay = `${i * 0.07}s`;
  });
});

// ─── FILTER BUTTONS ───────────────────────────────
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const parent = btn.closest('.filter-bar');
    parent.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;
    const grid = parent.nextElementSibling;
    if (!grid) return;

    grid.querySelectorAll('[data-category]').forEach(card => {
      if (filter === 'all' || card.dataset.category === filter) {
        card.style.display = '';
        setTimeout(() => card.classList.add('visible'), 10);
      } else {
        card.style.display = 'none';
        card.classList.remove('visible');
      }
    });
  });
});

// ─── NEWSLETTER FORM ──────────────────────────────
document.querySelectorAll('.nl-form').forEach(form => {
  form.addEventListener('submit', e => {
    e.preventDefault();
    const btn = form.querySelector('.nl-btn');
    btn.textContent = '✓ Subscribe ho gaye!';
    btn.style.background = '#059669';
    setTimeout(() => window.open('https://substack.com', '_blank'), 700);
  });
});

// ─── CONTACT FORM ─────────────────────────────────
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', e => {
    e.preventDefault();
    const btn = contactForm.querySelector('.form-submit');
    btn.textContent = '✓ Message bhej diya!';
    btn.style.background = '#059669';
    setTimeout(() => { btn.textContent = 'Message Bhejein →'; btn.style.background = ''; }, 3000);
  });
}
